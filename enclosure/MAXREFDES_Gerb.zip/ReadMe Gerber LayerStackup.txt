Gerber import information
Units Imperial
digit format 2.5
Integer 2
decimal 5
mode - absolute
zero suppression Leading

MAX32630SCBRev3.GTP		- Top pastemask
MAX32630SCBRev3.GTO		- Top silk screen
MAX32630SCBRev3.GTS		- Top Soldermask

MAX32630SCBRev3.GTL		- Top metal (layer 1)
MAX32630SCBRev3.G1		- internal Ground plane/signal layer(layer 2)
MAX32630SCBRev3.G2		- internal signal layer				(layer 3)
MAX32630SCBRev3.G3		- internal signal layer				(layer 4)
MAX32630SCBRev3.G4		- internal Power plane/signal layer	(layer 5)
MAX32630SCBRev3.GBL		- Bottom metal (layer 6)

MAX32630SCBRev3.GBS		- Bottom soldermask
MAX32630SCBRev3.GBO		- Bottom silk screen
MAX32630SCBRev3.GBP		- Bottom pastemask

MAX32630SCBRev3.GKO		- Mechanical / Board outline
MAX32630SCBRev3.GM11	- Mechanical / Top Assembly Information layer
MAX32630SCBRev3.GM12	- Mechanical / Bottom Assembly Information layer
MAX32630SCBRev3.GM31	- Mechanical / Fabrication Information layer

Drill import information 
Units Imperial
digit format 2.5
Integer 2
decimal 5
mode - absolute
zero suppression none

MAX32630SCBRev3.DRL				- All layer Drill
MAX32630SCBRev3.DR1				- layer 1 to layer 2 laser drill
MAX32630SCBRev3.DR2				- layer 2 to layer 3 laser drill

MAX32630SCBRev3-RoundHoles.TXT	- All layer Drill
MAX32630SCBRev3-RoundHoles.TX1	- layer 1 to layer 2 laser drill
MAX32630SCBRev3-RoundHoles.TX2	- layer 2 to layer 3 laser drill

MAX32630SCBRev3-SlotHoles.TXT	- All layer slot drill file 

MAX32630SCBRev3.GG1				- Drill Position/Guide file (all layers)
MAX32630SCBRev3.GG2				- Drill Position/Guide file (layer 2)
MAX32630SCBRev3.GG3				- Drill Position/Guide file (layer 3)

MAX32630SCBRev3.GD1				- Drill Symbol/Drawing file (all layer)
MAX32630SCBRev3.GD2				- Drill Symbol/Drawing file (layer 2 laser)
MAX32630SCBRev3.GD3				- Drill Symbol/Drawing file (layer 3 laser)

MAX32630SCBRev3.net				- IPC-D-356 Netlist file (if there are any conflicts go with the gerber data over the netlist file)
